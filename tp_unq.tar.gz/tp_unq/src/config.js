const config = {
  auth: {
    twitter: {
      consumer_key: 'itwNXkd4GIK29C0tdcj5XKoJk',
      consumer_secret: 'ELRGNtwsFUaC6wNfgwZGVeX6YVIpjrzc46OXCIRwUnrEMfLj0B',
      access_token_key: '194452244-04bBAi80eahbDS3XsaRBh3TpEUWBg5ly9cjcOmA2',
      access_token_secret: 'f57lASHglrAf2RDuJEo2gy2gIOZQUJTi2Y2ohqIHJ8mYX',
    },
    googleplaces: 'AIzaSyAY3nfamLON1qVwFFrmdM7pn42lNk5vBCI',
  },
};

module.exports = config;
