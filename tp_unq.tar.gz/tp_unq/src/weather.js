const { mk_error_response, mk_ok_response } = require('./utils.js');
const request = require('request');

function mk_weather_response(cityName) {
  return mk_ok_response(
    cityName
  );
}

module.exports = function (req, res) {
  const cityName = JSON.parse(req.query.city).name;

  let req_params = {
    q: `select * from weather.forecast where woeid in (select woeid from geo.places(1) where text="${cityName}") and u='c'`,
    format: 'json',
  };
  
  request({
    uri: 'https://query.yahooapis.com/v1/public/yql',
    qs: req_params,
    json: true,
    encoding: 'utf8',
  }, (error, rep) => {
    let clima = {};
    clima.lastlBuilDate = rep.body.query.results.channel.lastBuildDate;
    clima.location = rep.body.query.results.channel.location;
    clima.units = rep.body.query.results.channel.units;
    clima.atmosphere = rep.body.query.results.channel.atmosphere;
    clima.current = rep.body.query.results.channel.item.condition;
    clima.forecast = rep.body.query.results.channel.item.forecast;
    res.json(mk_weather_response(clima, null, 2));
  });
};