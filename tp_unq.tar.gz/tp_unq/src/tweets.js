const Twitter = require('twitter');
const config = require('./config');
const yandex =require('yandex-translate')('trnsl.1.1.20170525T183032Z.3f6e98f6d3d9efb4.11813a40bf8b71da961c43161fff0670b78affc7');
const promisify = require('util').promisify;
const translate = promisify(yandex.translate);
const { mk_error_response, mk_ok_response } = require('./utils');
/*
library doc - https://www.npmjs.com/package/twitter
twitter API doc - https://developer.twitter.com/en/docs/api-reference-index
twitter API - tweet object - https://developer.twitter.com/en/docs/tweets/data-dictionary/overview/tweet-object
twitter API - user object - https://developer.twitter.com/en/docs/tweets/data-dictionary/overview/user-object


Obtener user credentials:
  1. Loggearse a twitter
  2. IR a https://apps.twitter.com/
  3. Crear una app
     - en website poner http://www.example.com
  4. Ir a Keys and
  5. Poner las credenciales en el archivo config.js
*/

const client = new Twitter(config.auth.twitter);

function tweets(req, res) {
  const city = JSON.parse(req.query.city);
  const cityName = city.name;
  const params = {
    q: cityName,
    count: 10,
  };

  client.get('search/tweets', params).then(
    (response) => {
    let cant = 0;
    let usuarioTwitter = null;
    response.statuses.forEach((rec) => {
     if(rec.user.followers_count >= cant){
       cant = rec.user.followers_count;
       usuarioTwitter = rec.user;
     } 
    })
    return usuarioTwitter;  
  }
  ).then((user)=>{
    return (client.get('statuses/user_timeline',{screen_name: user.screen_name, count:2}));
  }).then((twets)=>{
    let tweet1 = {};
    let tweet2 = {};
    tweet1.text = twets[0].text;
    tweet2.text = twets[1].text;
    tweet1.user = twets[0].user.screen_name;
    tweet2.user= twets[1].user.screen_name;
    tweet1.lang = twets[0].user.lang;
    tweet2.lang = twets[1].user.lang;
    let lista = [tweet1, tweet2];
    return lista;
  }).then((response) => {
    translate(response[0].text, { to: 'es' }).then((t1) =>
      {response[0].text = t1.text;
        return response[0];
      }
    ).then((response2) =>{
      translate(response[1].text, { to: 'es'}).then((t2)=>
      {response[1].text = t2.text;
        return response[1];
      }
    ).then((solucion) => {
      let resultado = mk_ok_response([response[0],response[1]]);
      return res.json(resultado); 
       });
      });      
    }).
  catch((error) => res.json(
    res.json(mk_error_response(error))));
}

module.exports = tweets;


