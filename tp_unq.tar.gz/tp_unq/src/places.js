const { mk_error_response, mk_ok_response } = require('./utils');
const config = require('./config');
const GooglePlaces = require('node-googleplaces');
const placesApi = new GooglePlaces(config.auth.googleplaces);

function mk_places_response(cityName) {
  return mk_ok_response(cityName);
}

function places(req, res) {
  
    const cityName = JSON.parse(req.query.city).place_id;
    placesApi.details({place_id: cityName}).then((responses)=>{
      return responses;
    }).then((geo)=>{
      return geo.body.result;
    }).then((direccion)=>{
      return direccion.geometry.location;
    }).then((locacion)=>{
      let latitud = locacion.lat;
      let longitud= locacion.lng;
      let coord = latitud + ',' +longitud;
      let param = {
        location:  coord,
        radius: 2000,
      };
      return placesApi.nearbySearch(param);
    }).then((busqueda)=>{
      let interes = busqueda.body.results.filter((miInteres)=>miInteres.types.includes('food')); 
      return interes;
  }).then((lugaresInteresado)=>{

    res.json(mk_places_response(lugaresInteresado));
  })
    .catch((error) => res.json(
      res.json(mk_error_response(error)))
    );
}

module.exports = places;